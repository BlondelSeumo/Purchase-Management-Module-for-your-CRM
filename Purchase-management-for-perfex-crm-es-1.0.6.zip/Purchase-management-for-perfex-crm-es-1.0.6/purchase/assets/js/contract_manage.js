(function($) {
"use strict";  
	initDataTable('.table-table_contracts', admin_url+'purchase/table_contracts');
})(jQuery);